
# Setup Conda environment
```
conda create -n grid python=3.6
source activate grid
conda install -c bioconda bwa samtool cutadapt
conda install numpy scipy h5py pandas pysam
conda install snakemake
```
